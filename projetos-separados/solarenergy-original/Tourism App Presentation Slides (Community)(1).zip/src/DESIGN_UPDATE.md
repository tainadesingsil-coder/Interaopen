# 🎨 Modern Dark Design - Estilo App de Travel Premium

Design completamente renovado inspirado nos melhores apps de viagem modernos (Airbnb, Booking, Google Travel).

## 🌈 Paleta de Cores

### Dark Mode (Padrão)
```css
Background: #0f1419 (Quase preto)
Card: #1a1f28 (Cinza escuro)
Foreground: #ffffff (Branco)
Primary: #10b981 (Verde vibrante - Emerald)
Secondary: #3b82f6 (Azul elétrico)
Muted: #1e2530 (Cinza médio)
Muted Foreground: #94a3b8 (Cinza claro)
Border: rgba(255, 255, 255, 0.08) (Branco 8%)
Destructive: #ef4444 (Vermelho)
```

### Cores de Acento
- **Verde Primary**: #10b981 (usado para CTAs principais, ícones ativos)
- **Azul Secondary**: #3b82f6 (usado para cards de categorias)
- **Laranja**: #f97316 (usado para categoria Food)
- **Roxo**: #a855f7 (usado para categoria Hotels)
- **Rosa**: #ec4899 (usado para categoria Events)

## 📝 Tipografia

### Fonte Principal
**DM Sans** - Fonte sans-serif moderna e clean
- Heading: 700 (Bold)
- Subheading: 600 (Semibold)
- Body: 400 (Regular)
- Muted: 400 (Regular)

### Tamanhos
```css
h1: 2rem (32px) - Bold
h2: 1.5rem (24px) - Semibold
h3: 1.125rem (18px) - Semibold
h4: 1rem (16px) - Medium
p: 0.875rem (14px) - Regular
label: 0.75rem (12px) - Medium UPPERCASE
button: 0.875rem (14px) - Medium
```

## 🎯 Componentes Principais

### HomeScreen
- **Header** com localização e notificações
- **Search bar** com ícone
- **Categories grid** (4 colunas) com ícones coloridos e arredondados
- **Nearby Places** com cards horizontais
- **Create Tour CTA** com gradiente verde

### BottomNavigation
- Design flutuante com backdrop blur
- Background card arredondado (rounded-3xl)
- 4 tabs principais: Home, Map, Tours, Profile
- Active state com background verde
- Label apenas para tab ativo
- Animação de transição suave

### LoginScreen
- Background escuro com gradient orbs
- Card central com glassmorphism
- Inputs com ícones integrados
- Botão primary verde vibrante
- Demo credentials em card destacado
- Animações suaves de entrada

## 🎨 Sistema de Design

### Bordas
- Todas as bordas são `rounded-2xl` (1rem) ou `rounded-3xl` (1.5rem)
- Border color: rgba(255, 255, 255, 0.08) - super sutil

### Sombras
```css
Cards: 0 4px 16px rgba(0, 0, 0, 0.1)
Floating elements: 0 8px 32px rgba(0, 0, 0, 0.2)
```

### Espaçamento
- Padding interno: p-6 (1.5rem)
- Gap entre elementos: gap-4 (1rem)
- Margem entre seções: mb-8 (2rem)

### Ícones
- Tamanho padrão: w-5 h-5 (20px)
- Stroke width: 2
- Ícones ativos: stroke-width 2.5
- Cores vibrantes para categorias

## 🎭 Animações

### Motion
- **Fade in up**: Elementos aparecem de baixo para cima
- **Scale in**: Elementos crescem com spring animation
- **Hover**: Scale 1.05 e lift de 4px
- **Tap**: Scale 0.95
- **Transition**: cubic-bezier(0.16, 1, 0.3, 1) - suave e natural

### Delays
- Sequencial: 0.1s entre cada elemento
- Stagger: delay baseado no index

## 📱 Layout

### Grid System
- Categories: 4 colunas (grid-cols-4)
- Stats: 3 colunas (grid-cols-3)
- Nearby places: Stack vertical

### Cards
- Cards horizontais com imagem à esquerda
- Imagem: 96px x 96px (rounded-2xl)
- Content: padding interno de 1rem
- Hover: translateX(4px)

## 🌟 Características Especiais

### Glassmorphism
- Backdrop blur: 20px
- Background: rgba(26, 31, 40, 0.95)
- Border: rgba(255, 255, 255, 0.08)

### Gradient Buttons
```css
Primary: linear-gradient(to bottom right, #10b981, #059669)
Active tab: solid #10b981
```

### Status Indicators
- Verde: Online/Aberto
- Vermelho: Fechado
- Amarelo: Atenção

## 🎨 Ícones de Categoria

- 🗺️ **Explore**: Azul (#3b82f6)
- 🍽️ **Food**: Laranja (#f97316)
- 🏨 **Hotels**: Roxo (#a855f7)
- 🎭 **Events**: Rosa (#ec4899)

## 📐 Safe Areas

- Bottom navigation: pb-safe (respeita notch)
- Top header: pt-safe (respeita status bar)

## 🔄 Estados Interativos

### Hover
- Cards: lift de 4px + shadow elevada
- Buttons: opacity 90%
- Links: color shift para primary

### Active
- Tab: background primary + texto preto
- Input: border primary com 30% opacity

### Disabled
- Opacity: 50%
- Cursor: not-allowed

---

## 🚀 Resultado Final

Um design **ultra-moderno, escuro e vibrante** que combina:
- ✅ Paleta dark mode sofisticada
- ✅ Verde vibrante como cor principal
- ✅ Ícones coloridos e arredondados
- ✅ Tipografia clean e legível
- ✅ Animações suaves e naturais
- ✅ Layout espaçoso e respirável
- ✅ Glassmorphism e blur effects
- ✅ Mobile-first e responsivo

Inspirado nos melhores apps: **Airbnb + Uber + Spotify**