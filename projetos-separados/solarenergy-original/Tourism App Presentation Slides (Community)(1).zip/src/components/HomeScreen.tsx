import { motion } from "motion/react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useLanguage } from "../contexts/LanguageContext";
import { 
  MapPin, 
  Star, 
  Calendar,
  ArrowRight,
  Search,
  TrendingUp,
  Heart,
  Navigation,
  Clock,
  Sparkles,
  Award
} from "lucide-react";

interface HomeScreenProps {
  onCreateRoute: () => void;
}

export function HomeScreen({ onCreateRoute }: HomeScreenProps) {
  const { t } = useLanguage();

  const categories = [
    { icon: "🗺️", label: "Explorar", color: "from-blue-500 to-blue-600" },
    { icon: "🍽️", label: "Gastronomia", color: "from-orange-500 to-orange-600" },
    { icon: "🏨", label: "Hospedagem", color: "from-purple-500 to-purple-600" },
    { icon: "🎭", label: "Eventos", color: "from-pink-500 to-pink-600" },
  ];

  const nearbyPlaces = [
    {
      id: 1,
      name: "Praia de Rio Grande",
      location: "2.5 km de distância",
      image: "https://images.unsplash.com/photo-1721029145355-3fc6fe46b9a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWhpYSUyMGJyYXppbCUyMGJlYWNoJTIwcGFyYWRpc2V8ZW58MXx8fHwxNzU5MjQ3MzA5fDA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.8,
      reviews: 342,
      badge: "Popular"
    },
    {
      id: 2,
      name: "Centro Histórico",
      location: "1.2 km de distância",
      image: "https://images.unsplash.com/photo-1658336864160-13fdea79abb7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWhpYSUyMGNhdGhlZHJhbCUyMGNodXJjaCUyMGhpc3RvcmljYWx8ZW58MXx8fHwxNzU5MjQ3MzExfDA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.9,
      reviews: 189,
      badge: "Novidade"
    },
  ];

  const stats = [
    { value: "15+", label: "Locais", icon: MapPin },
    { value: "4.8", label: "Avaliação", icon: Star },
    { value: "3k+", label: "Visitantes", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header Premium */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-muted-foreground text-xs mb-1.5 uppercase tracking-wider">Localização</p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <h1 className="text-2xl">Belmonte, BA</h1>
            </div>
          </div>
          <button className="w-11 h-11 rounded-2xl bg-card flex items-center justify-center border border-border hover:bg-muted/50 transition-all hover:scale-105">
            <Bell className="w-5 h-5 text-foreground" strokeWidth={2} />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full text-[10px] text-white flex items-center justify-center font-medium">
              3
            </span>
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card border border-border rounded-2xl p-3 hover:bg-muted/30 transition-all cursor-pointer"
              >
                <Icon className="w-4 h-4 text-primary mb-2" strokeWidth={2} />
                <p className="text-lg text-foreground mb-0.5">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Search Premium */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" strokeWidth={2} />
          <input
            type="text"
            placeholder="Buscar destinos, restaurantes..."
            className="w-full h-14 bg-card border border-border rounded-2xl pl-12 pr-4 text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:ring-2 focus:ring-primary/20 transition-all"
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-emerald-600 rounded-xl flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" strokeWidth={2} />
            </div>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg">Categorias</h2>
          <Award className="w-4 h-4 text-primary" strokeWidth={2} />
        </div>
        <div className="grid grid-cols-4 gap-3">
          {categories.map((cat, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              whileHover={{ scale: 1.05, y: -4 }}
              whileTap={{ scale: 0.95 }}
              className="flex flex-col items-center gap-2.5"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${cat.color} rounded-[20px] flex items-center justify-center text-2xl shadow-lg hover:shadow-xl transition-shadow relative overflow-hidden`}>
                {/* Glossy effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent" />
                <span className="relative z-10">{cat.icon}</span>
              </div>
              <span className="text-[11px] text-foreground font-medium">{cat.label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Nearby Places */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl mb-0.5">Lugares Próximos</h2>
            <p className="text-xs text-muted-foreground">Descubra o que há por perto</p>
          </div>
          <button className="text-primary text-sm flex items-center gap-1 hover:gap-2 transition-all font-medium">
            Ver todos
            <ArrowRight className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>

        <div className="space-y-4">
          {nearbyPlaces.map((place, index) => (
            <motion.div
              key={place.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
              whileHover={{ x: 4 }}
              className="bg-card border border-border rounded-[24px] overflow-hidden cursor-pointer hover:shadow-lg transition-all group"
            >
              <div className="flex gap-4 p-2.5">
                <div className="relative w-28 h-28 rounded-[20px] overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={place.image}
                    alt={place.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {/* Overlay gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  {/* Badge */}
                  {place.badge && (
                    <div className="absolute top-2 left-2">
                      <Badge className="bg-primary/90 text-white border-0 text-[10px] px-2 py-0.5 backdrop-blur-sm">
                        {place.badge}
                      </Badge>
                    </div>
                  )}
                </div>
                <div className="flex-1 py-2 pr-3 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base mb-1.5 group-hover:text-primary transition-colors">{place.name}</h3>
                    <div className="flex items-center gap-2 text-muted-foreground text-xs mb-2">
                      <Navigation className="w-3.5 h-3.5" strokeWidth={2} />
                      <span>{place.location}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" strokeWidth={2} />
                      <span className="text-sm font-medium">{place.rating}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">({place.reviews} avaliações)</span>
                    <Heart className="w-4 h-4 text-muted-foreground ml-auto hover:text-destructive hover:fill-destructive transition-colors" strokeWidth={2} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Create Tour CTA Premium */}
      <div className="px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          onClick={onCreateRoute}
          className="relative bg-gradient-to-br from-primary via-emerald-500 to-emerald-600 rounded-[28px] p-6 cursor-pointer hover:scale-[1.02] active:scale-[0.98] transition-transform shadow-2xl shadow-primary/20 overflow-hidden"
        >
          {/* Animated background pattern */}
          <div className="absolute inset-0 opacity-10">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" x="0" y="0" width="32" height="32" patternUnits="userSpaceOnUse">
                  <circle cx="16" cy="16" r="1" fill="white" />
                </pattern>
              </defs>
              <rect x="0" y="0" width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Glossy overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent" />

          <div className="relative z-10 flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-white" strokeWidth={2} />
                <span className="text-white/80 text-xs uppercase tracking-wider font-medium">IA Personalizada</span>
              </div>
              <h3 className="text-white text-xl mb-1.5 font-semibold">Crie Seu Roteiro</h3>
              <p className="text-white/90 text-sm">Rotas personalizadas com inteligência artificial</p>
            </div>
            <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <ArrowRight className="w-7 h-7 text-white" strokeWidth={2.5} />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function Bell({ className, strokeWidth }: { className?: string; strokeWidth?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth || 2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"></path>
    </svg>
  );
}