import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Lock, Eye, EyeOff, AlertCircle, CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { LanguageSelector } from "./LanguageSelector";
import { useLanguage } from "../contexts/LanguageContext";
import belMascotImage from "figma:asset/f252610f6e9a8a9c93c9aaea8fde97dff0ee9a53.png";

interface LoginScreenProps {
  onLogin: () => void;
}

const DEMO_CREDENTIALS = {
  email: "demo@belmonte.com",
  password: "belmonte2024"
};

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const { t } = useLanguage();
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!isSignUp) {
      if (email === DEMO_CREDENTIALS.email && password === DEMO_CREDENTIALS.password) {
        setSuccess(true);
        setTimeout(onLogin, 1200);
      } else {
        setError("Email ou senha incorretos");
      }
    } else {
      if (name && email && password.length >= 6) {
        setSuccess(true);
        setTimeout(onLogin, 1200);
      } else {
        setError("Por favor, preencha todos os campos");
      }
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex items-center justify-center px-6">
      {/* Gradient orbs */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary/20 rounded-full blur-3xl" />

      {/* Language selector */}
      <div className="absolute top-6 right-6 z-50">
        <LanguageSelector />
      </div>

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        {/* Logo/Mascot */}
        <div className="text-center mb-8">
          <motion.div
            className="inline-block mb-6"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", duration: 0.8, delay: 0.2 }}
          >
            <div className="w-20 h-20 mx-auto bg-card rounded-3xl p-3 border border-border">
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <img
                  src={belMascotImage}
                  alt="Bel"
                  className="w-full h-full object-contain"
                />
              </motion.div>
            </div>
          </motion.div>

          <h1 className="text-3xl mb-2">
            Bem-vindo a <span className="text-primary">Belmonte</span>
          </h1>
          <p className="text-muted-foreground text-sm">
            Seu guia de viagem com IA
          </p>
        </div>



        {/* Login form */}
        <div className="bg-card border border-border rounded-3xl p-6">
          {/* Error/Success messages */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-2xl flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" strokeWidth={2} />
                <p className="text-xs text-destructive">{error}</p>
              </motion.div>
            )}
            
            {success && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-2xl flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4 text-primary" strokeWidth={2} />
                <p className="text-xs text-primary">Success! Welcome ✨</p>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name field */}
            <AnimatePresence>
              {isSignUp && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <label className="block text-xs text-muted-foreground mb-2">
                    FULL NAME
                  </label>
                  <Input
                    type="text"
                    placeholder="John Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full h-12 bg-background border-border rounded-2xl px-4"
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Email */}
            <div>
              <label className="block text-xs text-muted-foreground mb-2">
                EMAIL
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" strokeWidth={2} />
                <Input
                  type="email"
                  placeholder="demo@belmonte.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError("");
                  }}
                  className="w-full h-12 bg-background border-border rounded-2xl pl-11 pr-4"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs text-muted-foreground">
                  PASSWORD
                </label>
                {!isSignUp && (
                  <button 
                    type="button"
                    className="text-xs text-primary hover:text-primary/80"
                  >
                    Esqueceu?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" strokeWidth={2} />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  className="w-full h-12 bg-background border-border rounded-2xl pl-11 pr-11"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" strokeWidth={2} />
                  ) : (
                    <Eye className="w-4 h-4" strokeWidth={2} />
                  )}
                </button>
              </div>
            </div>

            {/* Submit button */}
            <Button
              type="submit"
              disabled={success}
              className="w-full h-12 bg-primary hover:bg-primary/90 text-black rounded-2xl font-medium disabled:opacity-50"
            >
              {success ? (
                <span className="flex items-center justify-center gap-2">
                  <CheckCircle className="w-4 h-4" strokeWidth={2} />
                  Sucesso!
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  {isSignUp ? "Criar Conta" : "Entrar"}
                  <ArrowRight className="w-4 h-4" strokeWidth={2} />
                </span>
              )}
            </Button>
          </form>

          {/* Toggle signup/login */}
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError("");
              }}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              {isSignUp ? (
                <>Já tem uma conta? <span className="text-primary">Entrar</span></>
              ) : (
                <>Não tem conta? <span className="text-primary">Criar agora</span></>
              )}
            </button>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-6">
          Ao continuar, você concorda com nossos{" "}
          <span className="text-primary cursor-pointer hover:underline">Termos de Uso</span>
        </p>
      </motion.div>
    </div>
  );
}