import { motion } from "motion/react";
import { Home, Map, Route, User, Calendar } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "home", icon: Home, label: "Início" },
    { id: "map", icon: Map, label: "Mapa" },
    { id: "routes", icon: Calendar, label: "Eventos" },
    { id: "profile", icon: User, label: "Perfil" }
  ];

  return (
    <motion.div 
      className="fixed bottom-0 left-0 right-0 z-50 pb-safe"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Background com blur */}
      <div className="mx-4 mb-4 bg-card/95 backdrop-blur-xl border border-border rounded-3xl shadow-2xl">
        <div className="relative px-2 py-3">
          <div className="flex items-center justify-around">
            {tabs.map((tab, index) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <motion.button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className="relative flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all"
                  whileTap={{ scale: 0.9 }}
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                >
                  {/* Active background */}
                  {isActive && (
                    <motion.div
                      layoutId="activeTabBg"
                      className="absolute inset-0 bg-primary rounded-2xl"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  
                  {/* Icon */}
                  <div className="relative z-10">
                    <Icon 
                      className={`w-6 h-6 transition-colors ${
                        isActive ? "text-black" : "text-muted-foreground"
                      }`}
                      strokeWidth={isActive ? 2.5 : 2}
                    />
                  </div>
                  
                  {/* Label - apenas para ativo */}
                  {isActive && (
                    <motion.span 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-[10px] font-medium text-black relative z-10"
                    >
                      {tab.label}
                    </motion.span>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    </motion.div>
  );
}