import { motion } from "motion/react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Calendar, 
  MapPin, 
  Clock, 
  Star,
  TrendingUp,
  Ticket,
  Users,
  Heart,
  Share2
} from "lucide-react";
import { events } from "../data/belmonte-database";

export function EventsScreen() {
  const categoryColors: Record<string, string> = {
    festival: "from-pink-500 to-rose-500",
    cultural: "from-purple-500 to-indigo-500",
    religious: "from-blue-500 to-cyan-500",
    sport: "from-orange-500 to-red-500",
  };

  const categoryLabels: Record<string, string> = {
    festival: "Festival",
    cultural: "Cultural",
    religious: "Religioso",
    sport: "Esporte",
  };

  const upcomingEvents = events.slice(0, 3);

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-muted-foreground text-xs mb-1.5 uppercase tracking-wider">Calendário</p>
            <h1 className="text-3xl">Eventos</h1>
          </div>
          <div className="flex gap-2">
            <button className="w-11 h-11 rounded-2xl bg-card flex items-center justify-center border border-border hover:bg-muted/50 transition-all">
              <Calendar className="w-5 h-5 text-foreground" strokeWidth={2} />
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-card border border-border rounded-2xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-primary" strokeWidth={2} />
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Próximos</span>
            </div>
            <p className="text-2xl text-foreground">{events.length}</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-secondary" strokeWidth={2} />
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Participantes</span>
            </div>
            <p className="text-2xl text-foreground">2.5k+</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Star className="w-4 h-4 text-accent" strokeWidth={2} />
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Gratuitos</span>
            </div>
            <p className="text-2xl text-foreground">{events.filter(e => e.price === 'Gratuito').length}</p>
          </div>
        </div>
      </div>

      {/* Filtros */}
      <div className="px-6 mb-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button className="flex-shrink-0 px-4 py-2 bg-primary text-black rounded-2xl text-sm font-medium">
            Todos
          </button>
          {Object.entries(categoryLabels).map(([key, label]) => (
            <button
              key={key}
              className="flex-shrink-0 px-4 py-2 bg-card border border-border rounded-2xl text-sm text-foreground hover:bg-muted/50 transition-all"
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Event */}
      {upcomingEvents.length > 0 && (
        <div className="px-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">Em Destaque</h2>
            <Ticket className="w-5 h-5 text-primary" strokeWidth={2} />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative rounded-[28px] overflow-hidden"
          >
            <div className="relative h-64">
              <ImageWithFallback
                src={upcomingEvents[0].image}
                alt={upcomingEvents[0].name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
              
              {/* Category badge */}
              <div className="absolute top-4 left-4">
                <Badge className={`bg-gradient-to-r ${categoryColors[upcomingEvents[0].category]} text-white border-0`}>
                  {categoryLabels[upcomingEvents[0].category]}
                </Badge>
              </div>

              {/* Price badge */}
              {upcomingEvents[0].price && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-primary/90 text-black border-0 backdrop-blur-sm">
                    {upcomingEvents[0].price}
                  </Badge>
                </div>
              )}

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-white text-2xl mb-2">{upcomingEvents[0].name}</h3>
                <p className="text-white/90 text-sm mb-4">{upcomingEvents[0].description}</p>
                
                <div className="flex items-center gap-4 text-white/90 text-sm mb-4">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" strokeWidth={2} />
                    <span>{upcomingEvents[0].date}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4" strokeWidth={2} />
                    <span>{upcomingEvents[0].location}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button className="flex-1 bg-primary hover:bg-primary/90 text-black rounded-2xl h-11">
                    Mais Informações
                  </Button>
                  <button className="w-11 h-11 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors">
                    <Heart className="w-5 h-5 text-white" strokeWidth={2} />
                  </button>
                  <button className="w-11 h-11 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center hover:bg-white/30 transition-colors">
                    <Share2 className="w-5 h-5 text-white" strokeWidth={2} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Próximos Eventos */}
      <div className="px-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl mb-0.5">Próximos Eventos</h2>
            <p className="text-xs text-muted-foreground">Não perca nenhuma atração</p>
          </div>
        </div>

        <div className="space-y-4">
          {events.slice(1).map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              whileHover={{ x: 4 }}
              className="bg-card border border-border rounded-[24px] overflow-hidden cursor-pointer hover:shadow-lg transition-all group"
            >
              <div className="flex gap-4 p-3">
                <div className="relative w-24 h-24 rounded-[20px] overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Category icon */}
                  <div className="absolute bottom-2 left-2">
                    <Badge className={`bg-gradient-to-r ${categoryColors[event.category]} text-white border-0 text-[10px] px-2 py-0.5`}>
                      {categoryLabels[event.category]}
                    </Badge>
                  </div>
                </div>

                <div className="flex-1 py-1 pr-2 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base mb-1.5 group-hover:text-primary transition-colors line-clamp-1">
                      {event.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-1">
                      {event.description}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar className="w-3.5 h-3.5" strokeWidth={2} />
                      <span>{event.date}</span>
                    </div>
                    {event.price && (
                      <Badge variant="outline" className="text-[10px] text-primary border-primary/30">
                        {event.price}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="px-6 mt-8">
        <div className="bg-gradient-to-br from-primary to-emerald-600 rounded-[24px] p-6 text-center">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Calendar className="w-6 h-6 text-white" strokeWidth={2} />
          </div>
          <h3 className="text-white text-lg mb-2">Não perca nenhum evento</h3>
          <p className="text-white/90 text-sm mb-4">
            Ative as notificações e fique por dentro
          </p>
          <Button className="bg-white hover:bg-white/90 text-primary rounded-2xl h-11 px-6">
            Ativar Notificações
          </Button>
        </div>
      </div>
    </div>
  );
}