import { motion } from "motion/react";
import { ReactNode } from "react";
import { cn } from "./ui/utils";

interface RefinedCardProps {
  children: ReactNode;
  className?: string;
  hoverable?: boolean;
  onClick?: () => void;
  gradient?: boolean;
}

export function RefinedCard({ 
  children, 
  className, 
  hoverable = false, 
  onClick,
  gradient = false 
}: RefinedCardProps) {
  const baseClasses = cn(
    "relative overflow-hidden rounded-3xl transition-all duration-500",
    gradient 
      ? "bg-gradient-to-br from-white/95 to-white/85 border border-white/20" 
      : "bg-card border-refined",
    hoverable && "cursor-pointer hover:shadow-elevated hover:border-primary/10",
    className
  );

  const Component = hoverable || onClick ? motion.div : "div";

  if (hoverable || onClick) {
    return (
      <Component
        className={baseClasses}
        onClick={onClick}
        whileHover={{ y: -4, transition: { duration: 0.3, ease: "easeOut" } }}
        whileTap={{ scale: 0.98 }}
      >
        {/* Subtle gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent pointer-events-none" />
        
        {/* Content */}
        <div className="relative z-10">
          {children}
        </div>
      </Component>
    );
  }

  return (
    <div className={baseClasses}>
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent pointer-events-none" />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}