import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles } from "lucide-react";
import { useState } from "react";
import belMascotImage from "figma:asset/f252610f6e9a8a9c93c9aaea8fde97dff0ee9a53.png";

interface AIBelProps {
  message: string;
  isVisible: boolean;
  position?: "bottom-right" | "bottom-left";
  context?: string;
}

export function AIBel({ message, isVisible, position = "bottom-right" }: AIBelProps) {
  const [showMessage, setShowMessage] = useState(false);

  if (!isVisible) return null;

  const positionClasses = position === "bottom-right" 
    ? "bottom-24 right-6" 
    : "bottom-24 left-6";

  return (
    <div className={`fixed ${positionClasses} z-40`}>
      <AnimatePresence>
        {/* Message bubble */}
        {showMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: "spring", bounce: 0.4, duration: 0.6 }}
            className="absolute bottom-20 right-0 mb-2 max-w-[280px]"
          >
            <div className="relative">
              {/* Card principal */}
              <div className="bg-gradient-to-br from-card to-muted border border-border/50 rounded-3xl p-4 shadow-2xl backdrop-blur-xl">
                {/* Close button */}
                <button
                  onClick={() => setShowMessage(false)}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-destructive rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                >
                  <X className="w-3 h-3 text-white" strokeWidth={2.5} />
                </button>

                {/* Content */}
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Sparkles className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground leading-relaxed">
                      {message}
                    </p>
                  </div>
                </div>

                {/* Shine effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent rounded-3xl pointer-events-none" />
              </div>

              {/* Tail */}
              <div className="absolute -bottom-2 right-8 w-4 h-4 bg-card border-r border-b border-border/50 transform rotate-45" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bel Avatar - Flutuante */}
      <motion.button
        onClick={() => setShowMessage(!showMessage)}
        className="relative group"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        animate={{ 
          y: [0, -12, 0],
        }}
        transition={{ 
          y: {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }
        }}
      >
        {/* Glow effect */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-br from-primary to-emerald-600 rounded-full blur-xl opacity-40"
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.4, 0.6, 0.4]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Main container */}
        <div className="relative w-16 h-16">
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-emerald-500 to-emerald-600 rounded-full shadow-2xl" />
          
          {/* Glossy overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-transparent rounded-full" />
          
          {/* Bel mascot */}
          <div className="absolute inset-0 flex items-center justify-center p-2">
            <img
              src={belMascotImage}
              alt="Bel - Assistente Virtual"
              className="w-full h-full object-contain drop-shadow-lg"
            />
          </div>

          {/* Pulse ring */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-primary"
            animate={{ 
              scale: [1, 1.5, 1],
              opacity: [0.8, 0, 0.8]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          {/* Notification dot */}
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
            }}
            transition={{ 
              duration: 1.5,
              repeat: Infinity,
            }}
            className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full border-2 border-background shadow-lg flex items-center justify-center"
          >
            <Sparkles className="w-2 h-2 text-white" strokeWidth={2.5} />
          </motion.div>
        </div>

        {/* Hover effect */}
        <div className="absolute inset-0 rounded-full bg-white/0 group-hover:bg-white/10 transition-colors" />
      </motion.button>
    </div>
  );
}