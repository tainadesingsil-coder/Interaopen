
  # Tourism App Presentation Slides (Community)

  This is a code bundle for Tourism App Presentation Slides (Community). The original project is available at https://www.figma.com/design/5oYIvE78v1k4mhv24XkRqE/Tourism-App-Presentation-Slides--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  