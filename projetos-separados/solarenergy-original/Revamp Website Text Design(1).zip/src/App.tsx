import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Benefits } from './components/Benefits';
import { About } from './components/About';
import { Differentials } from './components/Differentials';
import { Projects } from './components/Projects';
import { CallToAction } from './components/CallToAction';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Benefits />
      <About />
      <Differentials />
      <Projects />
      <CallToAction />
      <Contact />
      <Footer />
    </div>
  );
}
