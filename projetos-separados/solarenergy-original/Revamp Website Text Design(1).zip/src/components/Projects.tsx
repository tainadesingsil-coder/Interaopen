import { MapPin, Ruler, DollarSign, ImageIcon } from 'lucide-react';

export function Projects() {
  const projects = [
    {
      title: 'Loteamento Portal do Descobrimento',
      location: 'Porto Seguro - BA',
      area: 'Lotes de 250m² a 500m²',
      price: 'A partir de R$ 45.000',
      features: ['Parcelamento em 180x', 'Infraestrutura Completa', 'Próximo ao Centro']
    },
    {
      title: 'Residencial Costa Dourada',
      location: 'Arraial d\'Ajuda - BA',
      area: 'Terrenos de 300m² a 600m²',
      price: 'A partir de R$ 75.000',
      features: ['Área de Lazer', 'A 5min da Praia', 'Escritura Definitiva']
    },
    {
      title: 'Condomínio Vista do Atlântico',
      location: 'Trancoso - BA',
      area: 'Lotes de 400m² a 1000m²',
      price: 'A partir de R$ 120.000',
      features: ['Vista para o Mar', 'Segurança 24h', 'Alto Padrão']
    }
  ];

  return (
    <section id="empreendimentos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl lg:text-5xl text-gray-800">
            Nossos <span className="text-blue-500">Empreendimentos</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-500 to-orange-600 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Loteamentos estrategicamente localizados nas melhores áreas da Costa do Descobrimento. 
            Todos com infraestrutura completa, documentação regularizada e condições especiais de pagamento.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {projects.map((project, index) => (
            <div 
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-200"
            >
              {/* Image Placeholder */}
              <div className="relative overflow-hidden h-64 bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
                <div className="text-center space-y-2">
                  <ImageIcon className="w-16 h-16 text-gray-400 mx-auto" />
                  <p className="text-gray-500 text-sm">Imagem Projeto {index + 1}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <h3 className="absolute bottom-4 left-4 text-white text-2xl">
                  {project.title}
                </h3>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-blue-500 flex-shrink-0 mt-1" />
                    <span className="text-gray-700">{project.location}</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Ruler className="w-5 h-5 text-blue-500 flex-shrink-0 mt-1" />
                    <span className="text-gray-700">{project.area}</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <DollarSign className="w-5 h-5 text-blue-500 flex-shrink-0 mt-1" />
                    <span className="text-gray-700">{project.price}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <div className="flex flex-wrap gap-2">
                    {project.features.map((feature, idx) => (
                      <span 
                        key={idx}
                        className="text-xs bg-blue-50 text-blue-600 px-3 py-1 rounded-full"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                <button className="w-full bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white px-6 py-3 rounded-full transition-all duration-300 shadow-md hover:shadow-lg">
                  Saiba Mais
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
