import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export function Differentials() {
  const differentials = [
    {
      title: 'Documentação 100% Regularizada',
      description: 'Todos os nossos loteamentos possuem registro em cartório, matrícula individualizada e IPTU. Você investe com total segurança jurídica.'
    },
    {
      title: 'Infraestrutura Completa Entregue',
      description: 'Ruas pavimentadas, rede de água e esgoto, energia elétrica, iluminação pública e áreas de lazer já prontas para você aproveitar.'
    },
    {
      title: 'Parcelamento em Até 180 Meses',
      description: 'Condições especiais de pagamento direto com a construtora, sem consulta ao SPC/Serasa. Parcelas que cabem no seu bolso.'
    },
    {
      title: 'Escritura Definitiva Inclusa',
      description: 'Ao finalizar o pagamento, você recebe a escritura definitiva do seu terreno sem custos adicionais. Tudo muito transparente.'
    },
    {
      title: 'Região em Constante Valorização',
      description: 'A Costa do Descobrimento é um dos destinos mais procurados do Brasil. Seu investimento se valoriza ano após ano.'
    },
    {
      title: 'Atendimento Personalizado',
      description: 'Nossa equipe acompanha você do primeiro contato até a entrega das chaves. Estamos aqui para realizar seu sonho.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl lg:text-5xl text-gray-800">
            O que nos torna <span className="text-blue-500">diferentes</span>?
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-500 to-orange-600 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Não somos apenas mais uma imobiliária. Somos especialistas em transformar sonhos em realidade 
            com transparência, segurança e as melhores condições do mercado.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {differentials.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-gray-800">{item.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
