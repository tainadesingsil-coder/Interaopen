import { motion } from 'motion/react';
import { Phone, MessageCircle, Calendar } from 'lucide-react';

export function CallToAction() {
  return (
    <section className="py-20 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-orange-500 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <h2 className="text-4xl lg:text-5xl text-white">
              Pronto para construir seu <span className="text-amber-400">patrimônio</span>?
            </h2>
            <p className="text-xl text-blue-100">
              Não perca tempo! Terrenos em localizações privilegiadas são raros e se valorizam rapidamente. 
              Garanta já o seu e comece a construir o futuro da sua família.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="grid md:grid-cols-3 gap-6 pt-8"
          >
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 transition-all duration-300 border border-white/20">
              <Phone className="w-12 h-12 text-amber-400 mx-auto mb-4" />
              <h3 className="text-white mb-2">Ligue Agora</h3>
              <p className="text-blue-100 text-sm mb-4">
                Fale com um consultor
              </p>
              <a 
                href="tel:+557332882450"
                className="text-amber-400 hover:text-amber-300 transition-colors"
              >
                (73) 3288-2450
              </a>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 transition-all duration-300 border border-white/20">
              <MessageCircle className="w-12 h-12 text-amber-400 mx-auto mb-4" />
              <h3 className="text-white mb-2">WhatsApp</h3>
              <p className="text-blue-100 text-sm mb-4">
                Atendimento rápido
              </p>
              <a 
                href="https://wa.me/557332882450"
                className="text-amber-400 hover:text-amber-300 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                Iniciar Conversa
              </a>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 transition-all duration-300 border border-white/20">
              <Calendar className="w-12 h-12 text-amber-400 mx-auto mb-4" />
              <h3 className="text-white mb-2">Agende uma Visita</h3>
              <p className="text-blue-100 text-sm mb-4">
                Conheça pessoalmente
              </p>
              <button className="text-amber-400 hover:text-amber-300 transition-colors">
                Agendar Agora
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="pt-8"
          >
            <button className="bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white px-12 py-5 rounded-full transition-all duration-300 shadow-2xl hover:shadow-3xl hover:scale-105 text-lg">
              QUERO INVESTIR AGORA
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
