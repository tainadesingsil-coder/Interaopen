import { ImageIcon } from 'lucide-react';

export function About() {
  return (
    <section id="sobre" className="py-20 bg-gradient-to-br from-blue-50 to-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Image Placeholder */}
          <div className="relative">
            <div className="absolute -top-6 -left-6 w-full h-full bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl -z-10"></div>
            <div className="rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-gray-200 to-gray-300 h-[500px] flex items-center justify-center">
              <div className="text-center space-y-3">
                <ImageIcon className="w-20 h-20 text-gray-400 mx-auto" />
                <p className="text-gray-500">Imagem Sobre</p>
                <p className="text-sm text-gray-400">800 x 600px</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-4xl lg:text-5xl text-gray-800">
                Conheça a <span className="text-blue-500">InvestBA</span>
              </h2>
              <div className="w-20 h-1 bg-gradient-to-r from-amber-500 to-orange-600"></div>
            </div>

            <div className="space-y-4 text-gray-700 text-lg">
              <p>
                Há mais de <span className="font-semibold text-blue-500">30 anos</span>, a InvestBA é sinônimo de 
                <span className="font-semibold"> confiança e tradição</span> no mercado imobiliário da 
                <span className="font-semibold text-blue-500"> Costa do Descobrimento</span>. Somos especialistas em 
                loteamentos e terrenos em Porto Seguro, Arraial d'Ajuda, Trancoso e toda a região.
              </p>
              
              <p>
                Nossa <span className="font-semibold">missão</span> é democratizar o acesso à propriedade, oferecendo 
                condições especiais de pagamento e assessoria completa do início ao fim. Com 
                <span className="font-semibold text-blue-500"> documentação 100% regularizada</span>, você investe 
                com total segurança jurídica.
              </p>

              <p>
                Mais do que vender terrenos, ajudamos você a <span className="font-semibold">construir um patrimônio sólido</span> 
                em uma das regiões mais valorizadas do Brasil. Seja para morar, investir ou garantir o futuro da sua família, 
                a InvestBA é o seu parceiro ideal.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-6">
              <div className="text-center">
                <div className="text-4xl bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">+30</div>
                <div className="text-sm text-gray-600 mt-2">Anos de Experiência</div>
              </div>
              <div className="text-center">
                <div className="text-4xl bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">+5mil</div>
                <div className="text-sm text-gray-600 mt-2">Clientes Satisfeitos</div>
              </div>
              <div className="text-center">
                <div className="text-4xl bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">100%</div>
                <div className="text-sm text-gray-600 mt-2">Regularizado</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
