import { Facebook, Instagram, Phone, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-blue-600 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8 mb-8 max-w-5xl mx-auto">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl text-white italic">Invest</span>
              <span className="text-2xl text-amber-400">BA</span>
            </div>
            <p className="text-blue-100 text-sm">
              Loteamentos regularizados na Costa do Descobrimento há mais de 30 anos.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg mb-4 text-white">Contato</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-amber-400" />
                <a href="tel:+557332882450" className="text-blue-100 hover:text-white transition-colors">
                  (73) 3288-2450
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-amber-400" />
                <a href="mailto:contato@investba.com.br" className="text-blue-100 hover:text-white transition-colors">
                  contato@investba.com.br
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-lg mb-4 text-white">Redes Sociais</h4>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-blue-700 hover:bg-blue-800 flex items-center justify-center transition-colors duration-300"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-blue-700 hover:bg-blue-800 flex items-center justify-center transition-colors duration-300"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-blue-500 pt-6 text-center text-sm text-blue-100">
          <p>
            © {new Date().getFullYear()} InvestBA - Todos os direitos reservados
          </p>
        </div>
      </div>
    </footer>
  );
}
