import { motion } from 'motion/react';
import { ImageIcon } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen flex items-center pt-20">
      {/* Geometric Orange Shape */}
      <div className="absolute top-0 right-0 w-1/2 h-full">
        <div 
          className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-amber-500 to-orange-600"
          style={{
            clipPath: 'polygon(30% 0, 100% 0, 100% 100%, 50% 100%)'
          }}
        />
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
          {/* Left Content */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-8"
          >
            {/* Main Title */}
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-5xl lg:text-6xl xl:text-7xl bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent leading-tight"
            >
              SEU LEGADO COMEÇA<br />
              ONDE O CONTINENTE<br />
              TERMINA
            </motion.h1>
            
            {/* Description */}
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="text-gray-700 leading-relaxed text-xl"
            >
              Invista em terrenos e lotes na <span className="font-semibold text-blue-500">Costa do Descobrimento</span>, 
              a região mais valorizada do litoral baiano. Construa seu patrimônio com segurança jurídica, 
              infraestrutura completa e <span className="font-semibold text-blue-500">condições especiais de pagamento</span>.
            </motion.p>
            
            {/* Features */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.6 }}
              className="space-y-3"
            >
              <div className="flex items-center gap-3 text-gray-700 text-lg">
                <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                <span>Parcelamento em até 180x</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700 text-lg">
                <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                <span>30 anos de mercado</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700 text-lg">
                <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                <span>Documentação 100% regularizada</span>
              </div>
            </motion.div>

            {/* CTA Button */}
            <motion.button 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9, duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white px-10 py-5 rounded-full transition-all duration-300 shadow-lg hover:shadow-2xl text-lg"
            >
              QUERO CONHECER OS EMPREENDIMENTOS
            </motion.button>
          </motion.div>

          {/* Right Image */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="relative hidden lg:block"
          >
            <div className="rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-gray-200 to-gray-300 h-[600px] flex items-center justify-center">
              <div className="text-center space-y-3">
                <ImageIcon className="w-24 h-24 text-gray-400 mx-auto" />
                <p className="text-gray-500 text-xl">Imagem Hero</p>
                <p className="text-sm text-gray-400">1200 x 800px</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
