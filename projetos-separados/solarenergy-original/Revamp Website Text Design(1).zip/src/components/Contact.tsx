import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';

export function Contact() {
  return (
    <section id="contato" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden">
      {/* Decorative Shape */}
      <div 
        className="absolute top-0 left-0 w-1/3 h-full bg-red-600 opacity-5"
        style={{
          clipPath: 'polygon(0 0, 100% 0, 50% 100%, 0 100%)'
        }}
      ></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl lg:text-5xl text-gray-800">
            Fale <span className="text-blue-500">Conosco</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-amber-500 to-orange-600 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Nossa equipe está pronta para atendê-lo. Tire suas dúvidas, agende uma visita aos empreendimentos 
            ou solicite uma simulação personalizada. Invista com quem entende!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 space-y-6">
              <h3 className="text-2xl text-gray-800">Informações de Contato</h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-gray-800">Telefone / WhatsApp</div>
                    <a href="tel:+557332882450" className="text-blue-500 hover:underline">
                      (73) 3288-2450
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-gray-800">Email</div>
                    <a href="mailto:contato@investba.com.br" className="text-blue-500 hover:underline">
                      contato@investba.com.br
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-gray-800">Endereço</div>
                    <p className="text-gray-600">
                      Av. dos Navegantes, 123<br />
                      Centro - Porto Seguro/BA<br />
                      CEP: 45810-000
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-gray-800">Horário de Atendimento</div>
                    <p className="text-gray-600">
                      Segunda a Sexta: 8h às 18h<br />
                      Sábado: 9h às 13h
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg p-8 text-white">
              <h3 className="text-2xl mb-4">Quer conhecer os loteamentos?</h3>
              <p className="mb-6 opacity-90">
                Agende uma visita guiada e conheça pessoalmente nossos empreendimentos. 
                Nossa equipe mostrará todas as vantagens e tirará suas dúvidas.
              </p>
              <button className="w-full bg-white text-blue-500 px-6 py-3 rounded-full hover:bg-gray-100 transition-colors duration-300">
                Agendar Visita Gratuita
              </button>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl text-gray-800 mb-6">Envie uma Mensagem</h3>
            
            <form className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-gray-700 mb-2">
                  Nome Completo
                </label>
                <Input 
                  id="name"
                  type="text" 
                  placeholder="Seu nome"
                  className="w-full"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="email" className="block text-gray-700 mb-2">
                    Email
                  </label>
                  <Input 
                    id="email"
                    type="email" 
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-gray-700 mb-2">
                    Telefone
                  </label>
                  <Input 
                    id="phone"
                    type="tel" 
                    placeholder="(00) 00000-0000"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="interest" className="block text-gray-700 mb-2">
                  Empreendimento de Interesse
                </label>
                <Input 
                  id="interest"
                  type="text" 
                  placeholder="Qual empreendimento te interessa?"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-gray-700 mb-2">
                  Mensagem
                </label>
                <Textarea 
                  id="message"
                  placeholder="Conte-nos sobre seus planos e expectativas..."
                  rows={4}
                  className="w-full resize-none"
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white px-6 py-6 rounded-full transition-all duration-300 shadow-md hover:shadow-lg"
              >
                Enviar Mensagem
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
