import { Building2, ShieldCheck, TrendingUp, MapPin, FileCheck, Users } from 'lucide-react';

export function Benefits() {
  const benefits = [
    {
      icon: Building2,
      title: 'Infraestrutura Completa',
      description: 'Água, energia, ruas pavimentadas e iluminação em todos os loteamentos'
    },
    {
      icon: ShieldCheck,
      title: 'Segurança Jurídica Total',
      description: 'Documentação 100% regularizada com escritura definitiva e IPTU individual'
    },
    {
      icon: TrendingUp,
      title: 'Valorização Garantida',
      description: 'Região com crescimento anual de 12% e alta demanda turística'
    },
    {
      icon: MapPin,
      title: 'Localização Premium',
      description: 'Costa do Descobrimento: Porto Seguro, Arraial d\'Ajuda e Trancoso'
    },
    {
      icon: FileCheck,
      title: 'Parcelamento Facilitado',
      description: 'Entrada a partir de R$ 3.000 e parcelas que cabem no seu bolso'
    },
    {
      icon: Users,
      title: 'Mais de 30 Anos',
      description: 'Tradição, credibilidade e mais de 5 mil famílias realizadas'
    }
  ];

  return (
    <section id="beneficios" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl lg:text-5xl text-gray-800">
            Por que investir com a <span className="text-blue-500">InvestBA</span>?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transformamos sonhos em patrimônio há mais de três décadas. Conheça as vantagens de construir seu futuro conosco.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div 
                key={index}
                className="group p-8 rounded-xl bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:border-blue-400 hover:shadow-xl transition-all duration-300"
              >
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-gray-800">{benefit.title}</h3>
                  <p className="text-gray-600 text-sm">{benefit.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
