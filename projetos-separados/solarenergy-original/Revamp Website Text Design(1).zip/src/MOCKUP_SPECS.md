# Especificações de Mockup - InvestBA Landing Page

## 📐 Dimensões e Especificações de Imagens

### 1. Hero Section (Seção Principal)
**Localização:** `/components/Hero.tsx`
- **Imagem Principal:** 1200 x 800px
- **Formato:** JPG ou PNG
- **Sugestão de conteúdo:** Família feliz na praia, vista para o mar, ou paisagem da Costa de Descobrimento
- **Posição:** Centro do card branco
- **Estilo:** Bordas arredondadas (rounded-xl)

---

### 2. About Section (Sobre Nós)
**Localização:** `/components/About.tsx`
- **Imagem Principal:** 800 x 600px
- **Formato:** JPG ou PNG
- **Sugestão de conteúdo:** Desenvolvimento imobiliário, arquitetura moderna, ou vista aérea de empreendimentos
- **Posição:** Lado esquerdo da seção
- **Estilo:** Bordas arredondadas com sombra laranja/vermelha no fundo

---

### 3. Projects Section (Empreendimentos)
**Localização:** `/components/Projects.tsx`
- **Quantidade:** 3 imagens (uma para cada projeto)
- **Dimensões por imagem:** 600 x 400px
- **Formato:** JPG ou PNG
- **Sugestão de conteúdo:**
  1. **Loteamento Costa Verde:** Vista de lotes com infraestrutura
  2. **Residencial Paraíso:** Área de lazer ou residências
  3. **Condomínio Mar Azul:** Vista premium, praia ou alto padrão
- **Posição:** Topo de cada card
- **Estilo:** Gradiente escuro na parte inferior para sobreposição de texto

---

## 🎨 Paleta de Cores

### Cores Principais
- **Azul:** `#3B82F6` (blue-500)
- **Laranja/Âmbar:** `#F59E0B` (amber-500) até `#EA580C` (orange-600)
- **Cinza Claro:** `#F9FAFB` (gray-50)
- **Branco:** `#FFFFFF`

### Cores de Texto
- **Título Principal:** Gradiente Laranja (amber-500 → orange-600)
- **Títulos Secundários:** `#1F2937` (gray-800)
- **Destaques:** `#3B82F6` (blue-500)
- **Texto Corpo:** `#374151` (gray-700)

---

## 📱 Layout Responsivo

### Desktop (1920px)
- Container máximo: 1280px (max-w-7xl)
- Grid de 3 colunas para projetos
- Hero centralizado com largura máxima de 672px (max-w-2xl)

### Tablet (768px)
- Grid de 2 colunas para projetos
- Hero mantém centralização

### Mobile (320px - 767px)
- Grid de 1 coluna
- Stack vertical para todos os elementos

---

## 🎭 Animações (Motion)

### Hero Section
1. **Card Principal:**
   - Fade in com movimento Y (30px)
   - Duração: 0.8s
   
2. **Logo:**
   - Fade in
   - Delay: 0.3s
   
3. **Imagem:**
   - Fade in + Scale (0.95 → 1)
   - Delay: 0.5s
   
4. **Texto:**
   - Fade in com movimento Y (20px)
   - Delay: 0.7s
   
5. **Botão CTA:**
   - Fade in com movimento Y (20px)
   - Delay: 0.9s
   - Hover: Scale 1.02
   - Tap: Scale 0.98

---

## 📋 Seções da Landing Page

### 1. **Hero** - Seção Principal
- Logo InvestBA (Azul + Âmbar)
- Imagem central
- Título em gradiente laranja
- Descrição
- CTA Button laranja

### 2. **Benefits** - Benefícios
- 6 cards com ícones
- Grid 3 colunas (desktop)
- Ícones em círculos azuis
- Hover com elevação

### 3. **About** - Sobre Nós
- Layout de 2 colunas
- Imagem à esquerda
- Conteúdo à direita
- Estatísticas (30+ anos, 5000+ famílias, 100% segurança)

### 4. **Projects** - Empreendimentos
- Grid de 3 projetos
- Cards com imagem, informações e CTA
- Badges de características
- Hover com sombra elevada

### 5. **Contact** - Contato
- Layout de 2 colunas
- Informações de contato à esquerda
- Formulário à direita
- Card CTA adicional

### 6. **Footer** - Rodapé
- Grid de 4 colunas
- Links rápidos
- Serviços
- Informações de contato
- Redes sociais

---

## 🔧 Componentes Necessários

### UI Components (Shadcn)
- `Button` - Botões de ação
- `Input` - Campos de formulário
- `Textarea` - Campo de mensagem
- `Card` - Cards de conteúdo (opcional)

### Icons (Lucide React)
- `Building2` - Infraestrutura
- `ShieldCheck` - Segurança
- `TrendingUp` - Rentabilidade
- `MapPin` - Localização
- `FileCheck` - Documentação
- `Users` - Tradição
- `Phone` - Telefone
- `Mail` - Email
- `Clock` - Horário
- `ImageIcon` - Placeholder de imagens

---

## 📝 Textos Principais

### Slogan
**"EU LEGADO COMEÇA ONDE O CONTINENTE TERMINA"**

### Descrição
"Uma oportunidade única de construir seu patrimônio na Costa de Descobrimento com a segurança de 30 anos de experiência e assessoria jurídica completa."

### CTA Principal
"CONHEÇA MEU LEGADO"

---

## 🖼️ Como Adicionar as Imagens

1. Substituir os placeholders em cada componente
2. Remover a importação de `ImageIcon` do lucide-react
3. Adicionar novamente a importação do `ImageWithFallback`
4. Substituir as divs de placeholder pelas imagens reais

Exemplo:
```tsx
// Antes (Placeholder)
<div className="bg-gradient-to-br from-gray-200 to-gray-300 h-80 flex items-center justify-center">
  <ImageIcon className="w-20 h-20 text-gray-400" />
</div>

// Depois (Imagem Real)
<ImageWithFallback
  src="sua-imagem-aqui.jpg"
  alt="Descrição da imagem"
  className="w-full h-80 object-cover"
/>
```
