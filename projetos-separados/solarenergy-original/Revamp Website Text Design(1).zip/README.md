
  # Revamp Website Text Design

  This is a code bundle for Revamp Website Text Design. The original project is available at https://www.figma.com/design/C67nRwCXN5bILB5qOJXTgg/Revamp-Website-Text-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  